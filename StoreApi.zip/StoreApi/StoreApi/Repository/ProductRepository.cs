﻿using StoreApi.Abstract;
using StoreApi.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoreApi.Repository
{
    public class ProductRepository : IProductRepository
    {
        private readonly DemoContext _context;
        public ProductRepository(DemoContext context)
        {
            _context = context;
        }

        public IQueryable<Product> Products => _context.Products;

        public IUnitOfWork UnitOfWork => _context;

        public Product Add(Product item)
        {
            return _context.Products.Add(item).Entity;
        }

        public void Delete(Product item)
        {
            _context.Entry(item).State = Microsoft.EntityFrameworkCore.EntityState.Deleted;
        }

        public void Edit(Product item)
        {
            _context.Entry(item).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
        }
    }
}
