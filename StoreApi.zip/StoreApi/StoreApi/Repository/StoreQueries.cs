﻿using Dapper;
using Microsoft.Data.SqlClient;
using StoreApi.Abstract;
using StoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoreApi.Repository
{
    public class StoreQueries : IStoreQueries
    {
        private readonly string _connectionString;

        public StoreQueries(string strConnection)
        {
            _connectionString = strConnection;
        }

        public async Task<int> CountProductByCategory(int categoryId)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = @"
SELECT     COUNT(p.ProductId) as Total
FROM        Products AS p 
WHERE p.CategoryId = @category
";
                var result = await connection.ExecuteScalarAsync<int>(
                    query,
                    new { category = categoryId });

                return result;
            }
        }

        public async Task<List<ProductSummary>> GetProductSummaries()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = @"
SELECT     p.ProductId, p.ProductName, c.CategoryName
FROM        Products AS p INNER JOIN
                  Categories AS c ON p.CategoryId = c.CategoryId
";

                var result = await connection.QueryAsync<ProductSummary>(query);

                return result.ToList();
            }
        }

        public async Task<ProductSummary> GetProductSummaryById(int productId)
        {
            using (SqlConnection connection =new SqlConnection(_connectionString))
            {
                string query = @"
SELECT     p.ProductId, p.ProductName, c.CategoryName
FROM        Products AS p INNER JOIN
                  Categories AS c ON p.CategoryId = c.CategoryId
WHERE p.ProductId = @id
";

                var result = await connection.QueryAsync<ProductSummary>(
                    query,
                    new { id = productId }
                    );

                return result.FirstOrDefault();
            }
        }
    }
}
