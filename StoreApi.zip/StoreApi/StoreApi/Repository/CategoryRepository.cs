﻿using StoreApi.Abstract;
using StoreApi.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoreApi.Repository
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly DemoContext _context;
        public CategoryRepository(DemoContext context)
        {
            _context = context;
        }

        public IQueryable<Category> Categories => _context.Categories;

        public IUnitOfWork UnitOfWork => _context;

        public Category Add(Category item)
        {
            return _context.Categories.Add(item).Entity;
        }

        public void Delete(Category item)
        {
            _context.Entry(item).State = Microsoft.EntityFrameworkCore.EntityState.Deleted;
        }

        public void Edit(Category item)
        {
            _context.Entry(item).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
        }
    }
}
