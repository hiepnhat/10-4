﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoreApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private List<Student> students;
        public StudentsController()
        {
            //fake database
            students = new List<Student>();
            students.Add(new Student()
            {
                Course = ".NET",
                Id = 1,
                Name = "Vuong"
            });
            students.Add(new Student()
            {
                Course = "English",
                Id = 2,
                Name = "Mai"
            });
        }

        [HttpGet]
        [Route("list-students")]
        public IActionResult GetStudents()
        {
            return Ok(students);
        }

        [HttpGet]
        [Route("get-by-id/{id}")]
        public IActionResult GetStudentById(int id)
        {
            var student = students.FirstOrDefault(x => x.Id == id);
            if(student == null)
            {
                return NotFound();
            }
            return Ok(student);
        }

        [HttpPost]
        [Route("add-student")]
        public IActionResult AddStudent([FromBody] Student model)
        {
            if(model == null)
            {
                return BadRequest(new { error = 2, msg = "dữ liệu rỗng" });
            }
            var student = students.FirstOrDefault(x => x.Id == model.Id);
            if(student != null)
            {
                return BadRequest(new { error = 1, msg = "Id đã được sử dụng" });
            }

            students.Add(model);

            return Ok(new { error = 0, msg = "Thành công nhé" });
        }
    }
}
