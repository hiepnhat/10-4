﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StoreApi.Abstract;
using StoreApi.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoreApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        //inject db context
        private readonly DemoContext _context;

        private readonly IStoreQueries _storeQueries;

        public ProductsController(DemoContext context,
            IStoreQueries storeQueries)
        {
            _context = context;

            _storeQueries = storeQueries;
        }

        [HttpGet]
        [Route("list-categories")]
        public async Task<IActionResult> GetCategories()
        {
            var categories = await _context
                .Categories
                .Select(x => new { x.CategoryId, x.CategoryName })
                .ToListAsync();

            return Ok(categories);
        }

        [HttpGet]
        [Route("get-product-summary")]
        public async Task<IActionResult> GetProductSummry()
        {
            var items = await _storeQueries.GetProductSummaries();
            return Ok(items);
        }

        [HttpGet]
        [Route("get-product-summary-by-id/{id}")]
        public async Task<IActionResult> GetProductSummry(int id)
        {
            var item = await _storeQueries.GetProductSummaryById(id);

            if(item == null)
            {
                return NotFound();
            }

            return Ok(item);
        }

        [HttpGet]
        [Route("count-product-by-category/{id}")]
        public async Task<IActionResult> CountProductByCategory(int id)
        {
            var total = await _storeQueries.CountProductByCategory(id);

            return Ok(total);
        }

    }
}
