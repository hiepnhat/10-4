﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoreApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        [HttpGet]
        [Route("get-numbers")]
        public IEnumerable<int> GetNumbers()
        {
            List<int> numbers = new List<int>()
            {
                2,4,6,8,10
            };
            return numbers;
        }
    }
}
