﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StoreApi.Abstract;
using StoreApi.Entities;
using StoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoreApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CatalogController : ControllerBase
    {
        //setup DI
        private readonly ICategoryRepository _categoryRepository;
        private readonly IProductRepository _productRepository;

        public CatalogController(
            ICategoryRepository categoryRepository,
            IProductRepository productRepository)
        {
            _categoryRepository = categoryRepository;
            _productRepository = productRepository;
        }

        #region Category

        //list
        [HttpGet]
        [Route("list-categories")]
        public async Task<IActionResult> GetCategories()
        {
            var categories = await _categoryRepository
                .Categories
                .ToListAsync();

            return Ok(categories);
        }
        //get-by-id
        [HttpGet]
        [Route("get-category-by-id/{id}")]
        public async Task<IActionResult> GetCategoryById(int id)
        {
            var category = await _categoryRepository
                .Categories
                .FirstOrDefaultAsync(x => x.CategoryId == id);

            if(category == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(category);
            }
        }
        //add
        [HttpPost]
        [Route("add-category")]
        public async Task<IActionResult> AddCategory(
            [FromBody] CategoryDTO model
            )
        {
            var category = new Category()
            {
                CategoryName = model.CategoryName
            };
            _categoryRepository.Add(category);
            //save
            var result = await _categoryRepository.UnitOfWork.SaveAsync();
            if (result)
            {
                return Ok(new { status = 200, msg = "Thành công nhé." });
            }
            else
            {
                return BadRequest(new { status = 400, msg = "Lỗi rồi bạn ơi. ahuhu" });
            }
        }
        //update
        [HttpPut]
        [Route("edit-category/{id}")]
        public async Task<IActionResult> EditCategory(
            int id,
            [FromBody] CategoryDTO model
            )
        {
            var category = await _categoryRepository.Categories
                .FirstOrDefaultAsync(x => x.CategoryId == id);
            if(category == null)
            {
                return NotFound(new { status = 404, msg = "Không có bạn ơi"});
            }

            category.CategoryName = model.CategoryName;
            _categoryRepository.Edit(category);
            //save
            var result = await _categoryRepository.UnitOfWork.SaveAsync();
            if (result)
            {
                return Ok(new { status = 200, msg = "Thành công nhé." });
            }
            else
            {
                return BadRequest(new { status = 400, msg = "Lỗi rồi bạn ơi. ahuhu" });
            }
        }
        //delete
        [HttpDelete]
        [Route("delete-category/{id}")]
        public async Task<IActionResult> DeleteCategory(
            int id
            )
        {
            var category = await _categoryRepository.Categories
                .FirstOrDefaultAsync(x => x.CategoryId == id);
            if (category == null)
            {
                return NotFound(new { status = 404, msg = "Không có bạn ơi" });
            }

            _categoryRepository.Delete(category);
            //save
            var result = await _categoryRepository.UnitOfWork.SaveAsync();
            if (result)
            {
                return Ok(new { status = 200, msg = "Thành công nhé." });
            }
            else
            {
                return BadRequest(new { status = 400, msg = "Lỗi rồi bạn ơi. ahuhu" });
            }
        }
        #endregion

    }
}
