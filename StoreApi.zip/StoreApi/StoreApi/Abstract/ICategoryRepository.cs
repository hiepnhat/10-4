﻿using StoreApi.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoreApi.Abstract
{
    public interface ICategoryRepository : IRepository<Category>
    {
        IQueryable<Category> Categories { get; }
        Category Add(Category item);
        void Edit(Category item);
        void Delete(Category item);
    }
}
