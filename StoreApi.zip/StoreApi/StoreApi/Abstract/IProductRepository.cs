﻿using StoreApi.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoreApi.Abstract
{
    public interface IProductRepository : IRepository<Product>
    {
        IQueryable<Product> Products { get; }
        Product Add(Product item);
        void Edit(Product item);
        void Delete(Product item);
    }
}
