﻿using StoreApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoreApi.Abstract
{
    public interface IStoreQueries
    {
        Task<List<ProductSummary>> GetProductSummaries();

        Task<ProductSummary> GetProductSummaryById(int productId);

        Task<int> CountProductByCategory(int categoryId);
    }
}
