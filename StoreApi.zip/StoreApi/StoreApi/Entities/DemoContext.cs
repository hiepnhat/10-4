﻿using Microsoft.EntityFrameworkCore;
using StoreApi.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace StoreApi.Entities
{
    public class DemoContext : DbContext, IUnitOfWork
    {
        public DemoContext(
            DbContextOptions<DemoContext> options
            )
            : base(options)
        {

        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }

        public async Task<bool> SaveAsync(CancellationToken cancellationToken = default)
        {
            var result = await base.SaveChangesAsync(cancellationToken);
            return result > 0;
        }
    }
}
