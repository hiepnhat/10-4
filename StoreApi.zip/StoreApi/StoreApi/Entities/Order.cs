﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoreApi.Entities
{
    public class Order
    {
        [Key]
       public string OrderID { get; set; }
       public string CustomerID { get; set; }
       public string CustomerName { get; set; }
       public int OrderDate { get; set; }
       public string RequiredDate { get; set; }

       public string ShippedDate { get; set; }
       public int Total { get; set; }
    }
}
