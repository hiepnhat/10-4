﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoreApi.Entities
{
    public class Orderdetail {
    
        [Key]
        public int Id { get; set; }
        public int OderID { get; set; }
        public int ProductID { get; set; }
        public string Quantity { get; set; }
        public string Discount { get; set; }

    }
}
