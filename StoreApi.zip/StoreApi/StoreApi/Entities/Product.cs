﻿using System.ComponentModel.DataAnnotations;

namespace StoreApi.Entities
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string Suppliers.CompanyName { get; set; }
        public int Suppliers.ContactName { get; set; }
        public decimal CategoryName { get; set; }
        public int UnitPrice { get; set; }
        public string Discontinued { get; set; }
    }
}
